var searchData=
[
  ['lcdheight_0',['lcdHeight',['../struct_dev_type.html#ac05d347b65a6698b28ac6f7e1b3038c1',1,'DevType']]],
  ['lcdwidth_1',['lcdWidth',['../struct_dev_type.html#a1fd12d94aa7af1547f228623d51d7481',1,'DevType']]]
];
